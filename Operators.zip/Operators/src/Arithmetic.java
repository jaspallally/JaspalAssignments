public class Arithmetic {

    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        System.out.printf("a = %d b = %d%n",a,b);
        System.out.printf("Addition(a+b) : %d%n",a+b);
        System.out.printf("Subtraction(a-b) : %d%n",a-b);
        System.out.printf("Multiplication(a*b) : %d%n",a*b);
        System.out.printf("Division(a/b) : %d%n",a/b);
        System.out.printf("Modulus(a %% b) : %d%n",a%b);
        System.out.printf("Increment(a++) : %d%n",a++);
        System.out.printf("a = %d%n",a);
        System.out.printf("Increment(++a) : %d%n",++a);
        System.out.printf("a = %d%n",a);
        System.out.printf("Decrement(a--) : %d%n",a--);
        System.out.printf("a = %d%n",a);
        System.out.printf("Decrement(--a) : %d%n",--a);
        System.out.printf("a = %d%n",a);

    }

}
