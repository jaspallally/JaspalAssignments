public class Assignment {
    public static void main(String[] args) {
        int a = 12;
        int b = 7;
        int sum = a+b;
        System.out.printf("a = %d b = %d sum = %d %n",a,b,sum);
        a += b;
        System.out.printf("After a += b , a = %d%n",a);
        a -= b;
        System.out.printf("After a -= b , a = %d%n",a);
        a *= b;
        System.out.printf("After a *= b , a = %d%n",a);
        a /= b;
        System.out.printf("After a /= b , a = %d%n",a);
        a %= b;
        System.out.printf("After a %%= b , a = %d%n",a);

    }
}
