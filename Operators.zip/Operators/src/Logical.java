public class Logical {
    public static void main(String[] args) {
        int a = 15;
        int b = 15;
        System.out.printf("a = %d , b = %d%n",a,b);
        System.out.printf("a>10 && b>10 = %b%n",a>10 && b>10);
        System.out.printf("a<10 && b>10 = %b%n",a<10 && b>10);
        System.out.printf("a<10 && b<10 = %b%n",a<10 && b<10);
        System.out.printf("a==b && b==15 = %b%n",a==b && b==15);
        System.out.printf("true && true = %b%n",true && true);
        System.out.printf("true && false = %b%n",true && false);
        System.out.printf("false && false = %b%n",false && false);
        System.out.println();
        System.out.printf("a>10 || b>10 = %b%n",a>10 || b>10);
        System.out.printf("a<10 || b>10 = %b%n",a<10 || b>10);
        System.out.printf("a<10 || b<10 = %b%n",a<10 || b<10);
        System.out.printf("a==b || b==15 = %b%n",a==b || b==15);
        System.out.printf("true || true = %b%n",true || true);
        System.out.printf("true || false = %b%n",true || false);
        System.out.printf("false || false = %b%n",false || false);
        System.out.println();
        System.out.printf("!(a==12) = %b%n",!(a==12));
        System.out.printf("!(true) = %b%n",!(true));
    }
}
