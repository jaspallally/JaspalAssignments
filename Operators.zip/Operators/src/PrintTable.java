public class PrintTable {
    public static void main(String[] args) {
        System.out.printf("2 * 1 = %d%n",2*1);
        System.out.printf("2 * 2 = %d%n",2*2);
        System.out.printf("2 * 3 = %d%n",2*3);
        System.out.printf("2 * 4 = %d%n",2*4);
        System.out.printf("2 * 5 = %d%n",2*5);
        System.out.printf("2 * 6 = %d%n",2*6);
        System.out.printf("2 * 7 = %d%n",2*7);
        System.out.printf("2 * 8 = %d%n",2*8);
        System.out.printf("2 * 9 = %d%n",2*9);
        System.out.printf("2 * 10 = %d%n",2*10);
    }
}
