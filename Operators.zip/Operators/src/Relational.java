public class Relational {
    public static void main(String[] args) {
        int a =16;
        int b=14;
        System.out.printf("a = %d, b = %d%n",a,b);
        System.out.printf("a==b , Result = %b%n",a==b);
        System.out.printf("a!=b , Result = %b%n",a!=b);
        System.out.printf("a<b , Result = %b%n",a<b);
        System.out.printf("a>b , Result = %b%n",a>b);
        System.out.printf("a<=b , Result = %b%n",a<=b);
        System.out.printf("a>=b , Result = %b%n",a>=b);

    }
}
